# AulaFlow — Tu estudio, en orden

AulaFlow es una aplicación web para estudiantes que quieren organizar materias, entregas y sesiones de estudio desde un único panel. La idea es reducir el estrés de tener fechas y trabajos repartidos en distintos lugares.

## Funcionalidades

- Panel con tareas pendientes, completadas, entregas de hoy y porcentaje de avance.
- Crear, editar, completar y eliminar tareas.
- Clasificar tareas por materia, fecha, prioridad y tipo.
- Buscar tareas y filtrarlas por estado.
- Crear hasta 12 materias y asignarles colores.
- Resumen de progreso por materia.
- Temporizador de concentración con bloques de 25, 15 y 5 minutos; permite pausar y reiniciar.
- Tema oscuro y claro.
- Diseño adaptable a celular, tablet y escritorio.
- Persistencia local mediante `localStorage`; los datos permanecen en el navegador del dispositivo.

## Cómo ejecutar

No necesita instalar dependencias ni configurar un servidor.

1. Descargá o cloná este repositorio.
2. Abrí la carpeta `AulaFlow`.
3. Abrí `index.html` con Chrome, Firefox, Edge u otro navegador moderno.

También podés usar la extensión **Live Server** de Visual Studio Code para abrirlo con un servidor local.

## Estructura

```text
AulaFlow/
├── index.html          # Estructura de la aplicación
├── src/
│   ├── app.js          # Lógica, eventos y persistencia
│   └── styles.css      # Diseño responsive y temas
├── docs/
│   ├── idea.md         # Problema, usuarios y propuesta
│   ├── spec.md         # Requisitos funcionales y reglas
│   ├── plan.md         # Arquitectura y tecnologías
│   ├── tasks.md        # Plan de desarrollo
│   └── decisiones.md   # Decisiones de diseño
└── README.md
```

## Tecnologías

- HTML5
- CSS3
- JavaScript moderno (ES6+)
- Web Storage API (`localStorage`)

No utiliza backend ni servicios externos. La información se guarda localmente en el navegador y no se sincroniza entre dispositivos.

## Privacidad y límites

AulaFlow no solicita cuentas ni contraseñas. Las tareas y materias quedan guardadas en el almacenamiento local del navegador. Si se borran los datos del sitio o se cambia de dispositivo/navegador, esa información puede perderse. No es una plataforma multiusuario ni un sistema de sincronización en la nube.

## Estado

**Versión 1.0 — prototipo funcional.** Las funciones principales están implementadas. La sincronización en la nube, las cuentas y las notificaciones quedan fuera del alcance de esta versión.
