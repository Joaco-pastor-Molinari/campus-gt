# Especificación funcional

## Reglas de negocio

- **RN-01:** Cada tarea debe tener un título, una materia, una fecha de entrega, una prioridad y un tipo.
- **RN-02:** Una tarea puede marcarse como pendiente o completada.
- **RN-03:** Las tareas se pueden editar y eliminar.
- **RN-04:** Cada tarea pertenece a una materia existente.
- **RN-05:** El usuario puede crear hasta 12 materias.
- **RN-06:** No se permiten dos materias con el mismo nombre, ignorando mayúsculas y minúsculas.
- **RN-07:** El porcentaje de progreso se calcula como tareas completadas dividido por tareas totales. Si no hay tareas, el progreso es 0%.
- **RN-08:** Las tareas se ordenan mostrando primero las pendientes, luego por fecha y finalmente por prioridad.
- **RN-09:** Los datos se guardan en el almacenamiento local del navegador.
- **RN-10:** El temporizador permite seleccionar sesiones de 25, 15 o 5 minutos, pausar y reiniciar.

## Historias de usuario

- **HU-01:** Como estudiante quiero crear una tarea para registrar una entrega.
- **HU-02:** Como estudiante quiero asignar una materia para separar mis actividades.
- **HU-03:** Como estudiante quiero indicar fecha y prioridad para saber qué atender primero.
- **HU-04:** Como estudiante quiero marcar una tarea como completada para seguir mi progreso.
- **HU-05:** Como estudiante quiero buscar y filtrar tareas para encontrar rápidamente una actividad.
- **HU-06:** Como estudiante quiero ver un resumen por materia para entender cuánto avancé.
- **HU-07:** Como estudiante quiero usar un temporizador para concentrarme durante un período.
- **HU-08:** Como estudiante quiero que mis datos sigan disponibles al volver a abrir la página en el mismo navegador.

## Validaciones

- El título de una tarea no puede estar vacío y admite hasta 90 caracteres.
- El nombre de una materia no puede estar vacío y admite hasta 35 caracteres.
- Los detalles de una tarea son opcionales y admiten hasta 300 caracteres.
- La fecha de entrega es obligatoria.
- Una materia no se puede eliminar sin confirmar la acción; sus tareas asociadas también se eliminan.
