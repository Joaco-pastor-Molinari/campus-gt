# Plan de tareas

- [x] **T-01 — Estructura inicial:** crear HTML, CSS y JavaScript base.
- [x] **T-02 — Materias:** alta, colores, listado y eliminación.
- [x] **T-03 — Tareas:** alta, edición, eliminación y cambio de estado.
- [x] **T-04 — Organización:** búsqueda, filtros, prioridades y fechas.
- [x] **T-05 — Panel:** estadísticas, progreso general y por materia.
- [x] **T-06 — Enfoque:** temporizador configurable, pausa y reinicio.
- [x] **T-07 — Experiencia visual:** diseño responsive y tema claro/oscuro.
- [ ] **T-08 — Futuro:** exportar e importar datos de respaldo.
- [ ] **T-09 — Futuro:** pruebas automatizadas de reglas y operaciones.
