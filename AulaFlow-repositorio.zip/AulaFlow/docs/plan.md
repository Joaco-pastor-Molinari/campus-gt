# Plan técnico

## Arquitectura

Aplicación web estática de una sola página, dividida en tres partes:

1. **HTML (`index.html`):** estructura semántica, vistas, formularios y modales.
2. **CSS (`src/styles.css`):** sistema visual, componentes, tema claro/oscuro y adaptación responsive.
3. **JavaScript (`src/app.js`):** estado de la aplicación, reglas, eventos, renderizado y persistencia.

## Tecnologías

- HTML5 y CSS3 para la interfaz.
- JavaScript ES6+ sin framework para reducir dependencias.
- `localStorage` para conservar tareas, materias y preferencia de tema.

## Flujo de datos

Al iniciar, la aplicación intenta leer el estado guardado en `localStorage`. Si no existe, carga datos de demostración. Cada modificación actualiza el estado, lo guarda y vuelve a renderizar los componentes afectados.

## Seguridad y privacidad

La versión no maneja cuentas, contraseñas ni datos enviados a un servidor. El almacenamiento es local al navegador. No debe utilizarse como repositorio de información sensible.

## Mejoras futuras

- Exportar e importar una copia de seguridad JSON.
- Calendario mensual y vista semanal.
- Sincronización entre dispositivos con autenticación.
- Notificaciones de vencimientos.
- Pruebas automatizadas y accesibilidad ampliada.
