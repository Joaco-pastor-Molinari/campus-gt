# Decisiones del proyecto

## D-01 — Aplicación local en la primera versión
Se eligió una aplicación sin backend para que pueda ejecutarse abriendo `index.html`, sin cuentas, instalaciones ni configuración de base de datos. La contrapartida es que los datos no se sincronizan entre dispositivos.

## D-02 — JavaScript sin framework
Se priorizó una base liviana y fácil de comprender. La estructura separa presentación (HTML/CSS) y comportamiento (JavaScript).

## D-03 — Datos de demostración
La primera ejecución incluye algunas materias y tareas ficticias para que se puedan explorar las funciones inmediatamente. El usuario puede editarlas o eliminarlas.

## D-04 — Almacenamiento local
Se usa `localStorage` para conservar los cambios en el mismo navegador. La aplicación informa esta limitación en la interfaz y en el README.
