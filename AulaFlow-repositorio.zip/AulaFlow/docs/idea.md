# AulaFlow — Idea del proyecto

## Problema

Los estudiantes suelen tener tareas, evaluaciones y fechas de entrega repartidas entre carpetas, mensajes y distintas plataformas. Esto hace que sea fácil olvidarse de una actividad o no saber por dónde empezar.

## Propuesta

AulaFlow es un organizador académico sencillo que reúne materias, tareas y tiempo de estudio en un solo espacio. El usuario puede registrar qué tiene que hacer, cuándo debe entregarlo y qué prioridad tiene. Un panel resume el avance y un temporizador ayuda a reservar bloques de concentración.

## Usuarios

Estudiantes de nivel secundario, terciario o universitario que necesitan ordenar sus actividades académicas.

## Objetivo

Ayudar a planificar el estudio, visualizar las prioridades y mantener un registro claro del progreso sin sumar complejidad innecesaria.

## Diferencial

AulaFlow combina un gestor de tareas académico con un resumen por materia y un temporizador de enfoque. Está diseñado para empezar a usarlo sin registrarse ni configurar una cuenta.
